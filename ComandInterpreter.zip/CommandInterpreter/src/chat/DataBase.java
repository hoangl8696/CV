/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Joonas
 */
public class DataBase implements Observable{
    private final ArrayList<Message> chatHistory;
    private final Set<User> users;
    private String currentUser;
    private static DataBase instance = null;
    
    protected DataBase() {
        this.chatHistory = new ArrayList<>();
        this.users = new HashSet();
        this.currentUser = "";
    }
    
    public static DataBase getInstance(){
        if(instance == null) {
            instance = new DataBase();
        } 
        return instance;
    }
        
    public void appendHistory(Message m){
        chatHistory.add(m);
    }

    public ArrayList<Message> getChatHistory() {
        return chatHistory;
    }

    public Set<User> getUsers() {
        return this.users;
    }
    

    public void setCurrentUser(String currentUser) {
        this.currentUser = currentUser;
    }

    public String getCurrentUser() {
        return currentUser;
    }

    @Override
    public void register(User u) {
        this.users.add(u);
    }

    @Override
    public void deregister(User u) {
        this.users.remove(u);
    }

    @Override
    public void notifyObservers(Message m) {
        for(User u : this.users) {
            u.update(m);
        }
    }
    
        
}
