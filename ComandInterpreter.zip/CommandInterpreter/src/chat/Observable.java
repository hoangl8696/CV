package chat;

interface Observable {
    public void register(User u);
    public void deregister(User u);
    void notifyObservers(Message m);
}
