package chat;

interface Observer {
    public void update(Message m);
}
