package chat;

import java.io.IOException;
import java.net.*;
import java.io.PrintStream;

public class ChatServer {
    /*Database is a singleton object (only one instance) which implements observable
    * interface. Database takes care of preserving and updating of the chat data (history, users, etc.).
    * Database also takes care of notifying all active users when new message is sent.
    */
    
    private final DataBase data;
    

    public ChatServer() {
        /*getInstance() calls the DataBase constructor if data is not set (=null).
        * getInstance() return DataBase object.*/
        data = DataBase.getInstance();
    }
    
    /*ServerSocket.accept() throws IOException if I/O error occurs while waiting for connection.
    * IOException must be catched.*/
    public void serve() {
        try{
            ServerSocket mainSocket = new ServerSocket(0,3);
            System.out.println("Main socket port number " + mainSocket.getLocalPort());
            while(true) {
                Socket socket = mainSocket.accept();
                CommandInterpreter ci = new CommandInterpreter(socket.getInputStream(), new PrintStream(socket.getOutputStream(), true), data);
                Thread chatThread = new Thread(ci);
                chatThread.start();
            }
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
}
