package chat;

import java.util.Scanner;
import java.io.*;
import java.text.ParseException;

public class CommandInterpreter implements Runnable {
    private final Scanner reader;
    private final PrintStream output;
    private final DataBase data;
    private final User currentUser;

    public CommandInterpreter(InputStream in, PrintStream out, DataBase database) {
        this.reader = new Scanner(in);
        this.output = out;
        this.data = database;
        this.currentUser = new User("", in, out);
        this.data.register(currentUser);
    }
    @Override
    public void run(){
        output.println("Hello!");
        //clears input from any protocol dependant mess (telnet)
        reader.nextLine();
        boolean exit = false;
        while(!exit){
            output.print("> ");
            exit = this.interpretCommand(reader.nextLine());
        }
    }
    
    public boolean interpretCommand(String input) {
        String command = (input.contains(" ")) ? input.substring(0, input.indexOf(' ')) : input;
        switch(command){
            case ":list":
                output.println("Users:");
                for(User user : data.getUsers()){
                    output.println(user.getName());
                }
                output.println();
                break;
            case ":history":
                output.println("History:");
                for(Message entry : data.getChatHistory()){
                    output.println(entry.toString());
                }
                output.println();
                break;
            case ":user":
                if(input.contains(" ")){
                    currentUser.setName(input.substring(input.indexOf(' ') + 1));
                    output.println("Username is " + currentUser.getName());
                } else{
                    output.println("Username is " + currentUser.getName());
                }
                break;
            case ":quit":
                data.deregister(currentUser);
                output.println("Goodbye.");
                return true;
                
            default:
                if(currentUser.getName().equals("")){
                    output.println("Username not set. Give :user command.");
                } else{
                    Message m = new Message(currentUser, input);
                    data.appendHistory(m);
                    data.notifyObservers(m);
                    
                }
                break;
            }
        return false;
        
        
    }
    
}
